// Import router package
const router = require('express').Router();


//import validation package

const validator = require('validator');
/* Hand get requests for '/'
/* this is the index or home page
*/
router.get('/', (req, res) => {

    // set content type of response body in the headers
    res.setHeader('Content-Type', 'application/json');

    // Send a JSON response - this app will be a web api so no need to send HTML
    //res.end(JSON.stringify({message: 'This is the home page'}));
    res.json({content: 'Hello man, This is the default route.'});
});

// export
module.exports = router;

//calculator endpoints

// /add
//accepts 2 parameters via url querystring
// example: http://localhost:8080/add?a=3&b=2
