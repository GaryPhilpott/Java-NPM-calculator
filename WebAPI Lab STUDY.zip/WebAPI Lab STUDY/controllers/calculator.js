// Import router package
const router = require('express').Router();


//import validation package

const validator = require('validator');
/* Hand get requests for '/'
/* this is the index or home page
*/
router.get('/', (req, res) => {

    // set content type of response body in the headers
    res.setHeader('Content-Type', 'application/json');

    // Send a JSON response - this app will be a web api so no need to send HTML
    //res.end(JSON.stringify({message: 'This is the home page'}));
    res.json({content: 'Hello man, This is the default route.'});
});

// export
module.exports = router;

//calculator endpoints

// /add
//accepts 2 parameters via url querystring
// example: http://localhost:8080/add2?a=3&b=2

router.get('/add2', (req, res) => {

    //declare vars
    let numA = "";
    let numB = "";
    let op   = "";

    //validate input - input as a bad input could crash server or lead to an attack
    //check params exist; if they do assign values to vars
    if (typeof req.query.a != 'undefined')
        numA = req.query.a;
    
    if (typeof req.query.b != 'undefined')
        numB = req.query.b;

    if (typeof req.query.op != 'undefined')
        op = req.query.op;

//link to validator npm package @top of file
//If validation fails return error message

if (!validator.isNumeric(numA, { no_symbols: true}) || !validator.isNumeric(numB, { no_symbols: true})) {
    res.statusMessage = "Bad Request";
    res.status(400).end();
    return false;
}

const add = Number(numA) + Number(numB);
const sub = Number(numA) - Number(numB);
const div = Number(numA) / Number(numB);
const mul = Number(numA) * Number(numB);


const Addresult = {
    a: Number(numA),
    b: Number(numB),
    answer: add
};

const Subresult = {
    a: Number(numA),
    b: Number(numB),
    answer: sub
};

const Divresult = {
    a: Number(numA),
    b: Number(numB),
    answer: div
};

const Mulresult = {
    a: Number(numA),
    b: Number(numB),
    answer: mul
};

if (op == 'add'){
    res.json(Addresult);
}else if (op == 'sub'){
    res.json(Subresult)
}else if (op == 'div'){
    res.json(Divresult)
}else if (op == 'mul'){
    res.json(Mulresult)
}

});
